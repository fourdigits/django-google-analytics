from google_analytics.models import Analytics
from django.contrib import admin

admin.site.register(Analytics)
